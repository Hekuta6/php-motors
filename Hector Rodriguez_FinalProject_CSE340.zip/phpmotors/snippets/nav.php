
<?php
if (isset($navList)) {
    echo $navList;
} else {
    echo '<ul>
    <li><a href="/phpmotors/" title="PHP Motors Home">Home</a></li>
    <li><a href="#" title="classic cars">Classic</a></li>
    <li><a href="#" title="sports cars">Sports</a></li>
    <li><a href="#" title="sports utility vehicles">SUV</a></li>
    <li><a href="#" title="trucks">Trucks</a></li>
    <li><a href="#" title="used">Used</a></li>
</ul>';
}
?>