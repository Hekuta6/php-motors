<?php

function searchItems($searchInput)
{
    $db = phpmotorsConnect();
    $sql = "SELECT * FROM inventory WHERE invMake LIKE concat('%', :searchInput, '%')
    OR invModel LIKE concat('%', :searchInput, '%')
    OR invColor LIKE concat('%', :searchInput, '%')
    OR invDescription LIKE concat('%', :searchInput, '%')
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchInput', $searchInput, PDO::PARAM_STR);
    $stmt->execute();
    $itemMatch = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $itemMatch;
}


function searchPages($searchInput, $limit, $offset)
{
    $db = phpmotorsConnect();
    $sql = "SELECT inventory.*, carclassification.classificationName
    FROM inventory
    INNER JOIN carclassification
    ON inventory.classificationId LIKE carclassification.classificationId 
    WHERE invMake LIKE concat('%', :searchInput, '%')
    OR invModel LIKE concat('%', :searchInput, '%')
    OR invColor LIKE concat('%', :searchInput, '%')
    OR invDescription LIKE concat('%', :searchInput, '%')
    ORDER BY invPrice ASC
    LIMIT $limit OFFSET $offset
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchInput', $searchInput, PDO::PARAM_STR);
    $stmt->execute();
    $itemMatch = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $itemMatch;
}


?>
