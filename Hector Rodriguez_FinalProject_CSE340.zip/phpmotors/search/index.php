<?php
// Site Main controller

// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the PHP Motors model for use as needed
require_once '../model/main-model.php';
//Get the PHP Motors model for search
require_once '../model/search-model.php';

// Get the array of classifications
$classifications = getClassifications();



//get functions.php
require_once '../library/functions.php';


$page_title = 'Search';

$navList = setNavList($classifications);



$action = trim(filter_input(INPUT_POST, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
if ($action == NULL) {
    $action = trim(filter_input(INPUT_GET, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
}

switch ($action) {
    case 'error':
        include '../view/500.php';
        break;

    case 'search':
        $searchInput = trim(filter_input(INPUT_POST, 'search', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

        if (
            empty($searchInput)
        ) {
            $message = "<p class='top20px'>Please provide information for all empty form fields.</p>";
            $_SESSION['message'] = $message;
            include '../view/search.php';
            exit;
        }

        if (
            strlen($searchInput) < 3
        ) {
            $message = "<p class='top20px'>Please enter 3 or more characters.</p>";
            $_SESSION['message'] = $message;
            include '../view/search.php';
            exit;
        }

        $firstPageLink = buildFirstPageLink($searchInput);
        header('location: ' . $firstPageLink);

        include '../view/search.php';

        break;

    case 'find':

        include '../view/search.php';
        break;

    default:
        $item = $action;
        $page = trim(filter_input(INPUT_GET, 'page', FILTER_SANITIZE_NUMBER_INT));
        $currentPageLink = '/phpmotors/search/?action=' . $item . '&page=' . $page;

        $searchLimit = 10;
        $searchItems = searchItems($item);
        $searchCount = count($searchItems);

        if ($searchCount <= 0) {
            $_SESSION['notif'] = "<p class='notif'>Sorry no results for " . $item . "</p>";
            include '../view/search.php';
            break;
        } else {
            $_SESSION['notif'] = "<p class='notif'>Page " . $page . " of about " . $searchCount . " results</p>";
            $_SESSION['notif'] .= "<p class='notif'>Search results for \"" . $item . "\"</p>";
        }

        $totalPages = ceil($searchCount / $searchLimit);
        $offset = ($page - 1) * $searchLimit;

        $items = searchPages($item, $searchLimit, $offset);
        $itemLinks = buildSearchResults($items);

        if (!($totalPages <= 1)) {
            //build pagination links
            $pagesLinks = buildPageLinks($totalPages, $item);
            $paginationDisplay = buildPagination($pagesLinks, $currentPageLink, $item, $totalPages, $page);
        }
        // else {
        //     include '../view/search.php';
        //     exit;
        // }

        include '../view/search.php';
}
